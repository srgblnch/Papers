00readme.txt for AMS-LaTeX 2.0 [2004/08/06]

If you obtain AMS-LaTeX from CTAN, you will find that it now includes
a number of files for the "amsrefs" package. These may need separate
handling during the installation process (see amsrefs/install.txt).
The amsrefs package is not included in the AMS-LaTeX bundle distributed
from the AMS ftp site; it can be obtained separately from its own home
page (http://www.ams.org/tex/amsrefs.html).

A working LaTeX system is a prerequisite for using any of the components
of AMS-LaTeX.  [LaTeX and TeX are not AMS products; see the AMS TeX
Resources page (http://www.ams.org/tex/tex-resources.html) or the LaTeX
Project home page (http://www.latex-project.org/) for information if you
do not already have LaTeX.]

See install.txt for installation instructions. Installing from an
archive file such as ftp://ftp.ams.org/pub/tex/amsltx.zip is
recommended.

Version 2.0 of AMS-LaTeX consists of two main parts, amsmath and amscls.
Each part contains another 00readme.txt file with more specific
information.
